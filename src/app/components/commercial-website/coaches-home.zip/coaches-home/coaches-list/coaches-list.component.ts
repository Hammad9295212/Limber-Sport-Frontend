import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { SharedModule } from '../../../../shared.module';
import { Router } from '@angular/router';
import { CoachesService } from '../coaches.service';

@Component({
  selector: 'app-coaches-list',
  standalone: true,
  imports: [SharedModule, CommonModule],
  templateUrl: './coaches-list.component.html',
  styleUrl: './coaches-list.component.css'
})
export class CoachesListComponent {
  coachListData: any
  isCoachesList: boolean = true;
  isCoachesCard: boolean = false;

  constructor(
    private router: Router,
    private coachesService: CoachesService
  ) {

  }


  ngOnInit(): void {
    this.getCoachesListData()
  }

  getCoachesListData() {
    this.coachesService.getCoachList().subscribe(
      data => {
        if (data?.success === true && data?.status === 200) {
          console.log("Get API Successful", data)
          console.log(data.data)
          this.coachListData = data?.data
        } else {
          console.log("Get API Not Successful", data)
        }
      })
  }


  handleCoachesView(a: string) {
    if (a === 'list') {
      this.isCoachesCard = false;
      this.isCoachesList = true
    } else if (a === 'card') {
      this.isCoachesList = false;
      this.isCoachesCard = true
    }
  }

  handleCoachDetailsView(a: any) {
    console.log(a)
    this.router.navigate([`/coach-details/${a}`])
  }
}
