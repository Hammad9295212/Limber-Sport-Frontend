import { Component, OnInit } from '@angular/core';
import { SharedModule } from '../../../../shared.module';
import { CoachesService } from '../coaches.service';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-edit-coach-profile',
  standalone: true,
  imports: [SharedModule],
  templateUrl: './edit-coach-profile.component.html',
  styleUrl: './edit-coach-profile.component.css'
})
export class EditCoachProfileComponent implements OnInit {
  isCompleteProfile: boolean = false;
  userId: any
  coachDetailsData: any;
  coachDetailsForm: any;
  genderList: any;
  schoolList: any;
  universityList: any;
  companyList: any


  constructor(
    private fb: FormBuilder,
    private coachesService: CoachesService,
    private route: ActivatedRoute,
  ) { }

  ngOnInit(): void {
    this.getIdFromURL()
    this.getVarousData()
  }

  createForm() {
    console.log("Coach Details", this.coachDetailsData)
    this.coachDetailsForm = this.fb.group({
      user_id: [this.userId || '', Validators.required],
      gender_id: [this.coachDetailsData.gender_id || '', Validators.required],
      id: [this.coachDetailsData.id || '', Validators.required],
      profile_image: [this.coachDetailsData.profile_image || '', Validators.required],
      banner_image: [this.coachDetailsData.banner_image || '', Validators.required],
      dob: [this.coachDetailsData.dob || '', Validators.required],
      ethnicity_id: [this.coachDetailsData.ethnicity_id || '', Validators.required],
      school_id: [this.coachDetailsData.school_id || '', Validators.required],
      university_id: [this.coachDetailsData.university_id || '', Validators.required],
      company_id: [this.coachDetailsData.company_id || '', Validators.required],
      location: [this.coachDetailsData.location || '', Validators.required],
      heading_tagline: [this.coachDetailsData.heading_tagline || '', Validators.required],
      about_me: [this.coachDetailsData.about_me || '', Validators.required],
      website_link: [this.coachDetailsData.website_link || '', Validators.required],
    });
  }

  getIdFromURL() {
    this.route.paramMap.subscribe(params => {
      const id = params.get('id');
      console.log(id);
      this.userId = id;
    });
  }

  getVarousData() {
    this.coachesService.getGenderList().subscribe(
      data => {
        if (data?.success === true && data?.status === 200) {
          // console.log("Get API Successful", data)
          console.log(data.data)
          this.genderList = data?.data
        } else {
          console.log("Get Gender Not Successful", data)
        }
      })
    this.coachesService.getSchoolList().subscribe(
      data => {
        if (data?.success === true && data?.status === 200) {
          // console.log("Get API Successful", data)
          console.log(data.data)
          this.schoolList = data?.data
        } else {
          console.log("Get School Not Successful", data)
        }
      })
    this.coachesService.getUniversityList().subscribe(
      data => {
        if (data?.success === true && data?.status === 200) {
          // console.log("Get API Successful", data)
          console.log(data.data)
          this.universityList = data?.data
        } else {
          console.log("Get University Not Successful", data)
        }
      })
    this.coachesService.getCompanyList().subscribe(
      data => {
        if (data?.success === true && data?.status === 200) {
          // console.log("Get API Successful", data)
          console.log(data.data)
          this.companyList = data?.data
        } else {
          console.log("Get Company Not Successful", data)
        }
      })
    this.coachesService.getCoachDetails(this.userId).subscribe(
      data => {
        if (data?.success === true && data?.status === 200) {
          // console.log("Get API Successful", data)
          console.log(data.data)
          this.coachDetailsData = data?.data
          this.createForm()
        } else {
          console.log("Get Player Details Not Successful", data)
        }
      })
  }

  handleCompleteProfile() {
    this.isCompleteProfile = !this.isCompleteProfile
  }


}
