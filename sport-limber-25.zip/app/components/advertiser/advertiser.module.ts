import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdvertiserRoutingModule } from './advertiser-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    AdvertiserRoutingModule
  ]
})
export class AdvertiserModule { }
