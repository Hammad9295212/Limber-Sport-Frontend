import { Component } from '@angular/core';

@Component({
  selector: 'app-easy-book',
  standalone: true,
  imports: [],
  templateUrl: './easy-book.component.html',
  styleUrl: './easy-book.component.css'
})
export class EasyBookComponent {

}
