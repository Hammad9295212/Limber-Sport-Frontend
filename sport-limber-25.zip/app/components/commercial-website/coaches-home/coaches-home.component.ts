import {Component, ViewChild} from '@angular/core';
import {NgbCarouselModule, NgbCarousel, NgbSlideEvent, NgbSlideEventSource} from '@ng-bootstrap/ng-bootstrap';
import {SharedModule} from '../../../shared.module';
import {BannerComponent} from '../banner/banner.component';
import {Router} from '@angular/router';




@Component({
  selector: 'app-coaches-home',
  standalone: true,
  imports: [SharedModule, NgbCarouselModule, BannerComponent],
  templateUrl: './coaches-home.component.html',
  styleUrl: './coaches-home.component.css'
})
export class CoachesHomeComponent {

  canEditProfile: any = false;


  constructor(
    private router: Router
  ) {

  }

  paused = false;
  unpauseOnArrow = false;
  pauseOnIndicator = false;
  pauseOnHover: boolean = true;
  pauseOnFocus: boolean = false;
  showNavigationIndicators = true;
  showNavigationArrows = false;
  wrap = true;

  @ViewChild('carousel', {static: true}) carousel: NgbCarousel;

  togglePaused() {
    if (this.paused) {
      this.carousel.cycle();
    } else {
      this.carousel.pause();
    }
    this.paused = !this.paused;
  }

  onSlide(slideEvent: NgbSlideEvent) {
    if (
      this.unpauseOnArrow &&
      slideEvent.paused &&
      (slideEvent.source === NgbSlideEventSource.ARROW_LEFT ||
        slideEvent.source === NgbSlideEventSource.ARROW_RIGHT)
    ) {
      this.togglePaused();
    }
    if (
      this.pauseOnIndicator &&
      !slideEvent.paused &&
      slideEvent.source === NgbSlideEventSource.INDICATOR
    ) {
      this.togglePaused();
    }
  }

  navigateToHomePage() {
    this.router.navigate(['/home'])
  }

  handleCoachesListPage() {
    // this.router.navigate(['/coaches-list'])
    const queryParams: any = {'role_id': '4'};
    this.router.navigate(['/coaches-list'], {queryParams});

  }
}
