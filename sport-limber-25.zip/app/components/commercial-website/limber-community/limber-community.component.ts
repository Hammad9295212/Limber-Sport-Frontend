import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-limber-community',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './limber-community.component.html',
  styleUrl: './limber-community.component.css'
})
export class LimberCommunityComponent {

}
