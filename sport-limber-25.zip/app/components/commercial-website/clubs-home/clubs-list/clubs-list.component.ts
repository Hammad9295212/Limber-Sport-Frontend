import { Component } from '@angular/core';

@Component({
  selector: 'app-clubs-list',
  standalone: true,
  imports: [],
  templateUrl: './clubs-list.component.html',
  styleUrl: './clubs-list.component.css'
})
export class ClubsListComponent {

}
