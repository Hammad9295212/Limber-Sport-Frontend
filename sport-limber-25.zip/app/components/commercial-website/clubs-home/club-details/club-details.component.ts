import { Component } from '@angular/core';

@Component({
  selector: 'app-club-details',
  standalone: true,
  imports: [],
  templateUrl: './club-details.component.html',
  styleUrl: './club-details.component.css'
})
export class ClubDetailsComponent {

}
