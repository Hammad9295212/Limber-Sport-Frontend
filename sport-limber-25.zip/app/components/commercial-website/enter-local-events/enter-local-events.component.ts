import { Component } from '@angular/core';

@Component({
  selector: 'app-enter-local-events',
  standalone: true,
  imports: [],
  templateUrl: './enter-local-events.component.html',
  styleUrl: './enter-local-events.component.css'
})
export class EnterLocalEventsComponent {

}
