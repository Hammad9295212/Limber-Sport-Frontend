import { Component } from '@angular/core';

@Component({
  selector: 'app-make-friends',
  standalone: true,
  imports: [],
  templateUrl: './make-friends.component.html',
  styleUrl: './make-friends.component.css'
})
export class MakeFriendsComponent {

}
