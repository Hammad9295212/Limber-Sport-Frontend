import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CommercialWebsiteRoutingModule } from './commercial-website-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    CommercialWebsiteRoutingModule
  ]
})
export class CommercialWebsiteModule { }
