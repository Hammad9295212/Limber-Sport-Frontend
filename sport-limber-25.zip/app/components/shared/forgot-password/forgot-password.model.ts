export class UserRoles {
    id: number = 0;
    name: string = "";
    guard_name: string = "";
    created_at: string = "";
    updated_at: string = "";
}

