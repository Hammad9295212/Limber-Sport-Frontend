import {Component, Input} from '@angular/core';

@Component({
  selector: 'app-custom-spinner',
  standalone: true,
  imports: [],
  templateUrl: './custom-spinner.component.html',
  styleUrl: './custom-spinner.component.css'
})
export class CustomSpinnerComponent {
  @Input() isLoading: any = true;
}
